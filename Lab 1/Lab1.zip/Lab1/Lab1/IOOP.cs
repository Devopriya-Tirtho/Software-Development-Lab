﻿namespace Lab1
{
    public interface IOOP
    {
        void StudentInfo();
    }

    public class Student
    {
        public string Name { get; set; }
        public int ID { get; set; }
        public string Section { get; set; }
    }
}
